FontLib was designed and developed by Fabien Ménager.

### Current Team

* **Brian Sweeney** (maintainer)

### Alumni

* **Fabien Ménager** (creator)

### Contributors
* **mondrake**
* [and many more...](https://github.com/dompdf/php-font-lib/graphs/contributors)

### Thanks

FontLib would not have been possible without strong community support.
